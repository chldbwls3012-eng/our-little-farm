(() => {
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  const statusEl = document.getElementById("status");
  const coinsEl = document.getElementById("coins");
  const dayEl = document.getElementById("day");
  const messagesEl = document.getElementById("messages");
  const onlineEl = document.getElementById("online");
  const COLORS = ["#f28b82", "#fbbc04", "#81c995", "#8ab4f8", "#c58af9", "#ffadad"];
  const shirtColors = { blue:"#4d8ed1", red:"#df675d", green:"#59a66b", yellow:"#edc74f", purple:"#9a75c8" };
  const hairColors = { brown:"#70452d", black:"#302b2a", blonde:"#f2c35b", pink:"#e98cae" };
  let ws, myId = null, players = {}, crops = {}, myPlayer = null, selected = null;
  let keys = {}, lastMoveSent = 0, lastX = 0, lastY = 0, moveTarget = null;
  const tile = 48;

  function connect() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${proto}//${location.host}`);
    ws.onopen = () => {
      statusEl.textContent = "🟢 마을에 연결됐어요!";
      send({type:"join", name:document.getElementById("name").value});
    };
    ws.onclose = () => { statusEl.textContent = "연결이 끊겼어요. 재접속 중…"; setTimeout(connect, 1800); };
    ws.onerror = () => { statusEl.textContent = "서버 연결을 확인해 주세요."; };
    ws.onmessage = e => {
      const m = JSON.parse(e.data);
      if (m.type === "welcome") {
        myId = m.id; players = m.players || {}; crops = m.crops || {};
        if (m.day) dayEl.textContent = `${m.day}일차`;
        (m.chat || []).forEach(addChat);
        myPlayer = players[myId];
        if (myPlayer) { lastX = myPlayer.x; lastY = myPlayer.y; }
      } else if (m.type === "self") {
        myPlayer = m.player; players[myId] = m.player; coinsEl.textContent = m.player.coins;
      } else if (m.type === "playerJoined" || m.type === "playerUpdated") {
        players[m.player.id] = m.player;
        if (m.player.id === myId) { myPlayer = m.player; coinsEl.textContent = myPlayer.coins; }
      } else if (m.type === "playerMoved") {
        players[m.player.id] = {...players[m.player.id], ...m.player};
      } else if (m.type === "playerLeft") {
        delete players[m.id];
      } else if (m.type === "crops") {
        crops = m.crops;
      } else if (m.type === "chat") addChat(m.message);
      else if (m.type === "notice") addChat({name:"알림", text:m.text, color:"#d27c35"});
      onlineEl.textContent = `접속자 ${Object.keys(players).length}명`;
    };
  }
  function send(obj) { if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
  function addChat(m) {
    const div = document.createElement("div"); div.className = "message";
    const name = document.createElement("b"); name.textContent = `${m.name}: `;
    const text = document.createElement("span"); text.textContent = m.text;
    div.append(name, text); messagesEl.appendChild(div);
    while (messagesEl.children.length > 80) messagesEl.firstChild.remove();
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function rect(x,y,w,h,color) { ctx.fillStyle=color; ctx.fillRect(Math.round(x),Math.round(y),w,h); }
  function text(t,x,y,color="#fff",size=14) {
    ctx.font = `bold ${size}px monospace`; ctx.textAlign="center";
    ctx.lineWidth=3; ctx.strokeStyle="#4a623b"; ctx.strokeText(t,x,y); ctx.fillStyle=color; ctx.fillText(t,x,y);
  }
  function drawTree(x,y) {
    rect(x-10,y+8,20,24,"#865331"); rect(x-25,y-16,50,30,"#4b8d48");
    rect(x-18,y-27,36,20,"#62a950"); rect(x-4,y-32,8,8,"#83c35c");
  }
  function drawHouse(x,y) {
    rect(x-55,y-8,110,60,"#d9a66c"); rect(x-65,y-22,130,25,"#a85d48");
    rect(x-48,y-34,96,16,"#c97a57"); rect(x-12,y+18,24,34,"#704a36");
    rect(x-39,y+7,19,18,"#b8e5eb"); rect(x+22,y+7,19,18,"#b8e5eb");
    rect(x-17,y-52,34,18,"#f5d5a1"); text("우리 집",x,y-58,"#fff8df",12);
  }
  function drawPlayer(p, isMe) {
    const x=p.x, y=p.y;
    // Tiny chunky pixel character
    rect(x-8,y-18,16,6,hairColors[p.hair] || "#70452d");
    rect(x-10,y-13,20,13,"#f4c49a");
    rect(x-7,y-8,3,3,"#40382f"); rect(x+4,y-8,3,3,"#40382f");
    rect(x-11,y,22,16,shirtColors[p.clothes] || p.color || "#4d8ed1");
    rect(x-9,y+15,7,7,"#5b493c"); rect(x+2,y+15,7,7,"#5b493c");
    rect(x-15,y+2,4,11,"#f4c49a"); rect(x+11,y+2,4,11,"#f4c49a");
    text(p.name || "농부",x,y-24,isMe?"#fff3a3":"#fff",12);
  }
  function drawCrop(c) {
    rect(c.x-18,c.y-12,36,24,"#93613d");
    rect(c.x-16,c.y-10,32,20,"#b47a4d");
    if (c.ready) {
      rect(c.x-3,c.y-25,6,14,"#368447");
      rect(c.x-12,c.y-23,10,8,"#f3c94f"); rect(c.x+2,c.y-29,11,9,"#f3c94f");
      rect(c.x-5,c.y-15,10,6,"#58a84d");
      text("수확!",c.x,c.y-32,"#fff4a6",10);
    } else {
      const elapsed = Date.now() - c.plantedAt;
      const progress = Math.min(1, elapsed / c.growMs);
      rect(c.x-2,c.y-8-Math.floor(progress*10),4,8+Math.floor(progress*10),"#388b45");
      rect(c.x-8,c.y-7-Math.floor(progress*8),7,5,"#65b856");
      rect(c.x+1,c.y-12-Math.floor(progress*7),7,5,"#65b856");
      text("🌱",c.x,c.y-16,"#fff",12);
    }
  }
  function render() {
    // grass checkerboard
    rect(0,0,960,640,"#9acb75");
    for(let y=0;y<640;y+=48) for(let x=0;x<960;x+=48) {
      if (((x/48)+(y/48))%2===0) rect(x,y,48,48,"#a5d480");
      if ((x*7+y*3)%11===0) { rect(x+13,y+17,3,3,"#7db75d"); rect(x+31,y+31,3,3,"#7db75d"); }
    }
    // path and shared square
    rect(0,95,960,58,"#d8c18a"); rect(0,103,960,42,"#e7d4a5");
    rect(380,150,200,490,"#d8c18a"); rect(388,150,184,490,"#e7d4a5");
    drawHouse(480,100);
    // pond
    rect(75,210,105,74,"#5aaac0"); rect(85,218,85,58,"#7bc9d3");
    rect(95,225,22,5,"#b7e6e1"); text("연못",128,204,"#fff",12);
    // trees and flowers
    [[38,50],[115,65],[235,55],[315,70],[690,52],[790,75],[900,60],[50,360],[900,380],[80,570],[860,570]].forEach(a=>drawTree(a[0],a[1]));
    for(let i=0;i<26;i++){const x=(i*137+25)%950,y=(i*83+165)%620; if(y>155 && !(x>370&&x<590)) {rect(x,y,4,4,i%2?"#f7d2d9":"#fff2a5");rect(x+4,y,3,3,"#fff");}}
    // crop grid highlight
    if (selected) { ctx.strokeStyle="#fff2a0"; ctx.lineWidth=3; ctx.strokeRect(selected.x-24,selected.y-24,48,48); }
    Object.values(crops).forEach(drawCrop);
    Object.values(players).forEach(p=>drawPlayer(p,p.id===myId));
    text("공동 밭 · 탭해서 씨앗 심기",480,615,"#fff",14);
    requestAnimationFrame(render);
  }

  function canvasPoint(e) {
    const r=canvas.getBoundingClientRect();
    return {x:(e.clientX-r.left)*canvas.width/r.width, y:(e.clientY-r.top)*canvas.height/r.height};
  }
  canvas.addEventListener("pointerdown", e => {
    const pt=canvasPoint(e);
    let nearest=null, dmin=42;
    for(const c of Object.values(crops)){const d=Math.hypot(c.x-pt.x,c.y-pt.y); if(d<dmin){nearest=c;dmin=d;}}
    if(nearest) selected=nearest; else selected={x:Math.round(pt.x/tile)*tile,y:Math.round(pt.y/tile)*tile};
    if (myPlayer) moveTarget={x:pt.x,y:pt.y};
  });
  function move(dx,dy) {
    if(!myPlayer) return;
    myPlayer.x=Math.max(24,Math.min(936,myPlayer.x+dx));
    myPlayer.y=Math.max(24,Math.min(616,myPlayer.y+dy));
    const now=Date.now();
    if(now-lastMoveSent>65){send({type:"move",x:myPlayer.x,y:myPlayer.y});lastMoveSent=now;}
  }
  function loopMove() {
    if(keys.up) move(0,-3); if(keys.down) move(0,3); if(keys.left) move(-3,0); if(keys.right) move(3,0);
    if(moveTarget && myPlayer) {
      const dx=moveTarget.x-myPlayer.x, dy=moveTarget.y-myPlayer.y, d=Math.hypot(dx,dy);
      if(d<5) moveTarget=null; else move(dx/d*2.3,dy/d*2.3);
    }
    if(myPlayer){players[myId]=myPlayer; coinsEl.textContent=myPlayer.coins;}
    requestAnimationFrame(loopMove);
  }
  window.addEventListener("keydown",e=>{const map={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"}; if(map[e.key]){keys[map[e.key]]=true;e.preventDefault();}});
  window.addEventListener("keyup",e=>{const map={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"}; if(map[e.key])keys[map[e.key]]=false;});
  document.querySelectorAll("[data-move]").forEach(btn=>{
    const dir=btn.dataset.move;
    const on= e=>{e.preventDefault();keys[dir]=true;};
    const off=e=>{e.preventDefault();keys[dir]=false;};
    btn.addEventListener("pointerdown",on); btn.addEventListener("pointerup",off);
    btn.addEventListener("pointerleave",off); btn.addEventListener("pointercancel",off);
  });
  document.getElementById("plant").onclick=()=>{
    if(!selected){addChat({name:"안내",text:"먼저 밭을 터치해서 위치를 선택해 주세요."});return;}
    send({type:"plant",x:selected.x,y:selected.y}); selected=null;
  };
  document.getElementById("harvest").onclick=()=>{
    if(!myPlayer)return;
    let best=null,dist=70;
    for(const c of Object.values(crops)){const d=Math.hypot(c.x-myPlayer.x,c.y-myPlayer.y);if(d<dist){best=c;dist=d;}}
    if(best)send({type:"harvest",cropId:best.id});
    else addChat({name:"안내",text:"수확할 작물 가까이로 이동해 주세요."});
  };
  document.getElementById("saveLook").onclick=()=>{
    send({type:"customize",clothes:document.getElementById("clothes").value,hair:document.getElementById("hair").value});
    send({type:"join",name:document.getElementById("name").value,clothes:document.getElementById("clothes").value,hair:document.getElementById("hair").value});
  };
  document.getElementById("chatForm").addEventListener("submit",e=>{
    e.preventDefault();const input=document.getElementById("chatInput");
    if(input.value.trim())send({type:"chat",text:input.value.trim()});input.value="";input.focus();
  });
  connect(); render(); loopMove();
})();