const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const fs = require("fs");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const SAVE_FILE = path.join(DATA_DIR, "world.json");

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, players: players.size }));

const defaultWorld = () => ({
  crops: {},
  players: {},
  nextCropId: 1,
  day: 1
});
let world = defaultWorld();
const players = new Map();
const chatHistory = [];
const COLORS = ["#f28b82", "#fbbc04", "#81c995", "#8ab4f8", "#c58af9", "#ffadad"];

function loadWorld() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(SAVE_FILE)) {
      const saved = JSON.parse(fs.readFileSync(SAVE_FILE, "utf8"));
      world = { ...defaultWorld(), ...saved };
    } else saveWorld();
  } catch (err) {
    console.error("Could not load saved world:", err.message);
    world = defaultWorld();
  }
}
let saveTimer;
function saveWorld() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const snapshot = { ...world, players: {} };
      fs.writeFileSync(SAVE_FILE, JSON.stringify(snapshot, null, 2));
    } catch (err) {
      console.error("Save failed:", err.message);
    }
  }, 150);
}
function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function broadcast(data, except) {
  const payload = JSON.stringify(data);
  for (const ws of wss.clients) {
    if (ws !== except && ws.readyState === WebSocket.OPEN) ws.send(payload);
  }
}
function publicPlayers() {
  const out = {};
  for (const [id, p] of players) out[id] = p;
  return out;
}
function worldSnapshot() {
  return { type: "welcome", id: null, players: publicPlayers(), crops: world.crops, day: world.day };
}
function cleanName(value) {
  return String(value || "농부").replace(/[<>]/g, "").trim().slice(0, 12) || "농부";
}
function validPos(n, max) {
  return Number.isFinite(n) ? Math.max(24, Math.min(max - 24, n)) : 160;
}

loadWorld();

// A simple shared world clock: one in-game day every 10 real minutes.
// Crop growth continues while everyone is offline because plantedAt is persisted.
setInterval(() => {
  world.day = Math.floor(Date.now() / 600000) + 1;
  let changed = false;
  for (const crop of Object.values(world.crops)) {
    if (!crop.ready && Date.now() - crop.plantedAt >= crop.growMs) {
      crop.ready = true;
      changed = true;
    }
  }
  if (changed) broadcast({ type: "crops", crops: world.crops });
  saveWorld();
}, 10000).unref();

wss.on("connection", (ws) => {
  const id = Math.random().toString(36).slice(2, 10);
  ws.playerId = id;
  const player = {
    id, name: "농부", x: 180 + Math.random() * 100, y: 180 + Math.random() * 100,
    color: COLORS[Math.floor(Math.random() * COLORS.length)], hair: "brown",
    clothes: "blue", coins: 20
  };
  players.set(id, player);
  send(ws, { ...worldSnapshot(), id, players: publicPlayers(), chat: chatHistory.slice(-30) });
  broadcast({ type: "playerJoined", player }, ws);

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    const p = players.get(id);
    if (!p || !msg || typeof msg.type !== "string") return;

    if (msg.type === "join") {
      p.name = cleanName(msg.name);
      if (msg.color && COLORS.includes(msg.color)) p.color = msg.color;
      if (["blue", "red", "green", "yellow", "purple"].includes(msg.clothes)) p.clothes = msg.clothes;
      if (["brown", "black", "blonde", "pink"].includes(msg.hair)) p.hair = msg.hair;
      send(ws, { type: "self", player: p });
      broadcast({ type: "playerUpdated", player: p });
    }
    if (msg.type === "move") {
      p.x = validPos(Number(msg.x), 960);
      p.y = validPos(Number(msg.y), 640);
      broadcast({ type: "playerMoved", player: p }, ws);
    }
    if (msg.type === "plant") {
      const x = Math.round(Number(msg.x) / 48) * 48;
      const y = Math.round(Number(msg.y) / 48) * 48;
      if (!Number.isFinite(x) || !Number.isFinite(y) || x < 72 || x > 888 || y < 180 || y > 540) return;
      const occupied = Object.values(world.crops).some(c => c.x === x && c.y === y);
      if (occupied || p.coins < 2) {
        send(ws, { type: "notice", text: occupied ? "이미 작물이 자라고 있어요!" : "씨앗값이 부족해요!" });
        return;
      }
      p.coins -= 2;
      const cropId = String(world.nextCropId++);
      world.crops[cropId] = { id: cropId, x, y, plantedAt: Date.now(), growMs: 45000, ready: false, owner: id };
      broadcast({ type: "crops", crops: world.crops });
      broadcast({ type: "playerUpdated", player: p });
      saveWorld();
    }
    if (msg.type === "harvest") {
      const crop = world.crops[String(msg.cropId)];
      if (!crop || !crop.ready) {
        send(ws, { type: "notice", text: "아직 다 자라지 않았어요!" });
        return;
      }
      delete world.crops[crop.id];
      p.coins += 5;
      broadcast({ type: "crops", crops: world.crops });
      broadcast({ type: "playerUpdated", player: p });
      send(ws, { type: "notice", text: "수확 성공! 코인 5개를 얻었어요." });
      saveWorld();
    }
    if (msg.type === "chat") {
      const text = String(msg.text || "").replace(/[<>]/g, "").trim().slice(0, 160);
      if (!text) return;
      const item = { id, name: p.name, text, at: Date.now(), color: p.color };
      chatHistory.push(item);
      if (chatHistory.length > 100) chatHistory.shift();
      broadcast({ type: "chat", message: item });
    }
    if (msg.type === "customize") {
      if (msg.color && COLORS.includes(msg.color)) p.color = msg.color;
      if (["blue", "red", "green", "yellow", "purple"].includes(msg.clothes)) p.clothes = msg.clothes;
      if (["brown", "black", "blonde", "pink"].includes(msg.hair)) p.hair = msg.hair;
      broadcast({ type: "playerUpdated", player: p });
      send(ws, { type: "self", player: p });
    }
  });

  ws.on("close", () => {
    players.delete(id);
    broadcast({ type: "playerLeft", id });
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Our Little Farm running on http://localhost:${PORT}`);
});